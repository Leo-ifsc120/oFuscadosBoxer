CREATE TRIGGER [dbo].[TIServicos] ON [dbo].[TblServicosVendaProdutos]
FOR INSERT
AS
BEGIN
  DECLARE @CdProduto INT
  DECLARE @Cdservico INT
  DECLARE @qtprodutovenda numeric
  SELECT @Cdproduto = CdProduto,
         @Cdservico = CdServico,
		 @qtprodutovenda = QtProdutoVenda
  FROM INSERTED

  update TblProdutos set Qtestoque = Qtestoque - @qtprodutovenda where Cdproduto = @CdProduto

END
go

