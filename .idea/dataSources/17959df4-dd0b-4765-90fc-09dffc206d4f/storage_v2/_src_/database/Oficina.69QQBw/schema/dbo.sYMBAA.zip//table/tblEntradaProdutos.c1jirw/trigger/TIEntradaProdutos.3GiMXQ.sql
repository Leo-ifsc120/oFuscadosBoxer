CREATE TRIGGER [dbo].[TIEntradaProdutos] ON [dbo].[tblEntradaProdutos]
FOR INSERT
AS
BEGIN
  DECLARE	@CdProduto INT
  DECLARE	@CdentradaProdutos INT
  DECLARE	@qtprodutoEntrada numeric
  SELECT	@Cdproduto				= CdProduto,
			@CdentradaProdutos		= CdentradaProdutos,
			@qtprodutoEntrada		= qtprodutoEntrada
  FROM INSERTED

  update TblProdutos set Qtestoque = Qtestoque + @qtprodutoEntrada where Cdproduto = @Cdproduto

END
go

