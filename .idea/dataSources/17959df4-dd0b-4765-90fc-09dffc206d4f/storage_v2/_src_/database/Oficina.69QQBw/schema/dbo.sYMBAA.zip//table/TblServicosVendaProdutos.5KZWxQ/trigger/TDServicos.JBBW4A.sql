CREATE TRIGGER [dbo].[TDServicos] ON [dbo].[TblServicosVendaProdutos]
FOR delete
AS
BEGIN
  DECLARE @CdProduto INT
  DECLARE @Cdservico INT
  DECLARE @qtprodutovenda numeric
  SELECT @Cdproduto = CdProduto,
         @Cdservico = CdServico,
		 @qtprodutovenda = QtProdutoVenda
  FROM deleted

  update TblProdutos set Qtestoque = Qtestoque + @qtprodutovenda where Cdproduto = @CdProduto

END
go

