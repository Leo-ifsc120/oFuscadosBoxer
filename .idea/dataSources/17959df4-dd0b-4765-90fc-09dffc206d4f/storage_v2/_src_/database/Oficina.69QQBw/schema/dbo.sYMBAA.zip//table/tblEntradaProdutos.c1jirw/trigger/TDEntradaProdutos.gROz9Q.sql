CREATE TRIGGER [dbo].[TDEntradaProdutos] ON [dbo].[tblEntradaProdutos]
FOR delete
AS
BEGIN
  DECLARE	@CdProduto INT
  DECLARE	@CdentradaProdutos INT
  DECLARE	@qtprodutoEntrada numeric
  SELECT	@Cdproduto				= CdProduto,
			@CdentradaProdutos		= CdentradaProdutos,
			@qtprodutoEntrada		= qtprodutoEntrada
  FROM deleted

  update TblProdutos set Qtestoque = Qtestoque - @qtprodutoEntrada where Cdproduto = @Cdproduto

END
go

