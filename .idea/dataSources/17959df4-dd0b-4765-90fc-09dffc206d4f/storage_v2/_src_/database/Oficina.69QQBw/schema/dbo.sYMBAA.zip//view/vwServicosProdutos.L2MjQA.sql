CREATE VIEW vwServicosProdutos 
AS
select CdServico, SUM(QtProdutoVenda * VlProdutoVenda) AS VlTotal, 0 AS InTipoProduto
From TblServicosVendaProdutos
GROUP BY CdServico
UNION ALL 
select CdServico, SUM(Qtservicosprestados * VlProdutoVenda) AS VlTotal, 1 AS InTipoProduto
From TblServicosprestadosVenda
GROUP BY CdServico
go

